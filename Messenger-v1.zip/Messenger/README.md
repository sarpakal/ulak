# 📬 Messenger Platform (Multi-Channel Messaging System)

## 🚀 Overview

Messenger Platform is a **modular, multi-channel messaging system** built with **.NET 9, ASP.NET Core Web API, and .NET MAUI**.
It allows sending messages through multiple communication channels from a single backend service.

Supported channels:

* 📱 SMS (via Corvass API)
* 💬 WhatsApp (via WhatsApp Business API - WABA)
* 📧 Email (via SMTP / MailKit)
* 🔔 Push Notifications (via Firebase Cloud Messaging - FCM)

---

## 🎯 Goals

* Build a **centralized messaging service** for multiple channels
* Keep **API keys and secrets secure** on the backend
* Provide a **scalable and extensible architecture**
* Enable **mobile control via .NET MAUI app**
* Follow **Clean Architecture principles**
* Allow easy **integration with other systems**

---

## 🏗️ Architecture

```
Messenger.sln
 ├── Messenger.Core
 │    ├── Interfaces
 │    ├── DTOs (Records)
 │    └── Messenger (Facade)
 │
 ├── Messenger.Infrastructure
 │    ├── SMS (Corvass)
 │    ├── WhatsApp (WABA)
 │    ├── Email (SMTP)
 │    └── Push (FCM)
 │
 ├── Messenger.Api
 │    └── ASP.NET Core Web API
 │
 └── Messenger.App
      └── .NET MAUI Mobile App
```

---

## 🔄 How It Works

1. 📱 MAUI App sends a request to the Web API
2. 🌐 Web API receives and validates the request
3. 🧠 Messenger (Core) routes the message
4. 🔌 Infrastructure layer sends via the selected provider
5. ✅ Response returned to the client

---

## 📡 API Endpoints

| Method | Endpoint                 | Description            |
| ------ | ------------------------ | ---------------------- |
| POST   | `/api/messages/sms`      | Send SMS               |
| POST   | `/api/messages/whatsapp` | Send WhatsApp          |
| POST   | `/api/messages/email`    | Send Email             |
| POST   | `/api/messages/push`     | Send Push Notification |

---

## ⚙️ Configuration

Example `appsettings.json`:

```json
{
  "Messaging": {
    "Corvass": {
      "SmsUrl": "https://api.corvass.com/",
      "ApiKey": "your-key",
      "ApiSecret": "your-secret"
    },
    "WhatsApp": {
      "BaseUrl": "https://graph.facebook.com/v19.0/",
      "PhoneNumberId": "your-id",
      "AccessToken": "your-token"
    },
    "Email": {
      "SmtpHost": "smtp.gmail.com",
      "SmtpPort": 587,
      "Username": "your@email.com",
      "Password": "your-app-password"
    },
    "Notifications": {
      "BaseUrl": "https://fcm.googleapis.com/",
      "ServerKey": "your-fcm-key"
    }
  }
}
```

---

## 📱 MAUI Client

The mobile app:

* Sends requests to the API
* Uses MVVM pattern
* Supports all messaging channels
* Can be extended to show message history & logs

---

## 🧩 Technologies Used

* .NET 10
* ASP.NET Core Web API
* .NET MAUI
* MailKit (Email)
* Firebase Cloud Messaging (Push)
* WhatsApp Business API (WABA)
* Twilio and Corvass SMS API
* Dependency Injection + HttpClientFactory

---

## 🔐 Security

* API keys stored only in backend
* No sensitive data exposed to mobile app
* Ready for JWT authentication (future enhancement)

---

## 🚀 Future Improvements

* ✅ Message history & logging
* 🔄 Retry mechanism for failed messages
* 📊 Dashboard & analytics
* 🔑 JWT authentication & user management
* 🧵 Background queue (Hangfire / Azure Queue)
* 📬 Bulk messaging support (Google Sheets integration)

---

## 👨‍💻 Author

Developed by **Sarp Akal**
📍 Based in Raleigh, NC

---

## ⭐ Contributing

Contributions are welcome!
Feel free to open issues or submit pull requests.

---

## 📄 License

This project is licensed under the MIT License.
