using Messenger.Core.Options;
using Messenger.Infrastructure.Config;


var builder = WebApplication.CreateBuilder(args);

// === 1. Load settings ===
var config = builder.Configuration;

// Configuration (from appsettings.json or environment variables)

builder.Services.Configure<EmailOptions>(
    config.GetSection("Messaging:Email"));

builder.Services.Configure<CorvassApiOptions>(
    config.GetSection("Messaging:CorvassApi"));

builder.Services.Configure<WhatsAppOptions>(
    config.GetSection("Messaging:Whatsapp"));

builder.Services.Configure<FcmNotificationOptions>(
    config.GetSection("Messaging:FcmNotification"));

// === 2. Register DbContext ===

// === 3. Register Services ===
builder.Services.AddMessengerInfrastructure();

// Add services to the container.

// === 4. Add Controllers ===
builder.Services.AddControllers();
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

// === 5. Add Authentication & JWT ===
// === 6. Add Authorization ===
// === 7. Swagger ===

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
