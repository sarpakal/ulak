﻿using Messenger.Core;
using Messenger.Core.Options;
using Messenger.Infrastructure.Senders;
using Microsoft.Extensions.DependencyInjection;

namespace Messenger.Infrastructure.Config
{
    public static class MessengerInfrastructureModule
    {
        public static IServiceCollection AddMessengerInfrastructure(this IServiceCollection services)
        {
            // === 1. Load settings ===



            // Core services
            services.AddSingleton<IEmailSender, SmtpEmailSender>();
            services.AddSingleton<ISmsSender, CorvassSmsSender>();
            services.AddSingleton<IWhatsAppMessageSender, WhatsappSender>();
            services.AddSingleton<IPushNotificationSender, FcmPushSender>();

            // Add validators, messaging, repositories here as needed
            // services.AddScoped<IUserRepository, PostgresUserRepository>();
            // services.AddScoped<IMessageSender, SmsMessageSender>();

            return services;
        }
    }
}
/*
Usage in Program.cs:
    builder.Services.AddMessengerInfrastructure();
Usage in Startup.cs:
    services.AddMessengerInfrastructure();
*/
