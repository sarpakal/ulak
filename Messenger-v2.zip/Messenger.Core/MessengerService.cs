﻿// File name: MessengerService.cs
// File purpose: Central entry point for sending messages via different channels
// Description:
// This code defines a MessengerService class that acts as a facade for sending messages through various channels such as Email, SMS, WhatsApp, and Push Notifications. It uses interfaces to abstract the implementation details of each messaging service, allowing for easy extension and maintenance.
// Facade (Central Entry) 
// using interfaces for different messaging services
// Project target framework: .NET 10.0

namespace Messenger.Core;

public class MessengerService(
    IEmailSender emailSender,
    ISmsSender smsSender,
    IWhatsAppMessageSender whatsappSender,
    IPushNotificationSender pushSender)
{
    private readonly IEmailSender _emailSender = emailSender;
    private readonly ISmsSender _smsSender = smsSender;
    private readonly IWhatsAppMessageSender _whatsAppSender = whatsappSender;
    private readonly IPushNotificationSender _pushSender = pushSender;

    public Task SendEmailAsync(EmailMessage message) => _emailSender.SendAsync(message);
    public Task SendSmsAsync(SmsMessage message) => _smsSender.SendAsync(message);
    public Task SendWhatsappAsync(WhatsAppMessage message) => _whatsAppSender.SendAsync(message);
    public Task SendPushAsync(PushMessage message) => _pushSender.SendAsync(message);

}
