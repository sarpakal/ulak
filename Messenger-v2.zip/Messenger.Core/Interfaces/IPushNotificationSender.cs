﻿using System.Threading.Tasks;

namespace Messenger.Core.Interfaces;

public interface IPushNotificationSender
{
    Task SendAsync(PushMessage message);
}
