﻿// File name: IEmailSender.cs

using System.Threading.Tasks;
namespace Messenger.Core.Interfaces;

public interface IEmailSender
{
    Task SendAsync(EmailMessage message);
}
