﻿using System.Threading.Tasks;

namespace Messenger.Core.Interfaces;

public interface ISmsSender
{
    Task SendAsync(SmsMessage message);
}
