﻿
namespace Messenger.Core.Interfaces;

public interface IWhatsAppMessageSender
{
    Task SendAsync(WhatsAppMessage message);
}
