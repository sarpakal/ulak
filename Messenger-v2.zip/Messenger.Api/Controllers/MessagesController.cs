﻿using Messenger.Core;
using Messenger.Core.DTOs;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Messenger.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MessagesController : ControllerBase
    {
        private readonly MessengerService _messengerService;

        public MessagesController(MessengerService messengerService)
        {
            _messengerService = messengerService;
        }

        [HttpPost("email")]
        public async Task<IActionResult> SendEmail([FromBody] EmailMessage msg)
        {
            await _messengerService.SendEmailAsync(msg);
            return Ok(new { status = "Email sent" });
        }

        [HttpPost("sms")]
        public async Task<IActionResult> SendSms([FromBody] SmsMessage msg)
        {
            await _messengerService.SendSmsAsync(msg);
            return Ok(new { status = "SMS sent" });
        }

        [HttpPost("whatsapp")]
        public async Task<IActionResult> SendWhatsapp([FromBody] WhatsAppMessage msg)
        {
            await _messengerService.SendWhatsappAsync(msg);
            return Ok(new { status = "WhatsApp sent" });
        }

        [HttpPost("push")]
        public async Task<IActionResult> SendPush([FromBody] PushMessage msg)
        {
            await _messengerService.SendPushAsync(msg);
            return Ok(new { status = "Push sent" });
        }

        [HttpGet("/")]
        [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
        public IActionResult Index()
        {
            return Ok("Messenger is running.");
        }
    }
}
