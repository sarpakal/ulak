﻿using Messenger.Core;
using Messenger.Core.Interfaces;
using Messenger.Core.Options;
using Messenger.Infrastructure.Senders;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Http;

namespace Messenger.Infrastructure.Config
{
    public static class MessengerInfrastructureModule
    {
        public static IServiceCollection AddMessengerInfrastructure(this IServiceCollection services)
        {
            // ── Senders — Scoped to match MessengerService lifetime ───────
            services.AddScoped<IEmailSender, SmtpEmailSender>();
            services.AddScoped<IWhatsAppMessageSender, WhatsappSender>();
            services.AddScoped<IPushNotificationSender, FcmPushSender>();

            // CorvassSmsSender1 takes HttpClient — must use AddHttpClient
            services.AddHttpClient<ISmsSender, CorvassSmsSender1>();

            // ── Messenger facade ──────────────────────────────────────────
            services.AddScoped<MessengerService>();

            return services;
        }
    }
}