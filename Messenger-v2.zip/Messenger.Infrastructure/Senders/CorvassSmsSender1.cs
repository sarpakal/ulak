﻿using Messenger.Core.Options;
using Microsoft.Extensions.Options;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace Messenger.Infrastructure.Senders;

public class CorvassSmsSender1 : ISmsSender
{
    private readonly HttpClient _httpClient;
    private readonly CorvassApiOptions _options;

    public CorvassSmsSender1(HttpClient httpClient, IOptions<CorvassApiOptions> options)
    {
        _httpClient = httpClient;
        _options = options.Value;
    }

    public async Task SendAsync(SmsMessage message)
    {
        //using var client = new HttpClient();

        var payload = new
        {
            Authentication = new
            {
                apikey = _options.ApiKey,
                apisecret = _options.ApiSecret
            },
            msisdnArray = message.To, //msisdnArray = new[] { message.To },
            message = message.Text,
            originator = "", // "AKAL YNT."
            senddate = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss"),
            tags = new[] { "customer", "crm" },
            description = "",
            messageType = "B", // B = Business, R = Regular
            recipientType = "" // "TACIR" (commercial) or "BIREYSEL" (individual)
        };

        var response = await _httpClient.PostAsJsonAsync(_options.SmsUrl, payload);
        response.EnsureSuccessStatusCode();

        if (!response.IsSuccessStatusCode)
        {
            var error = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"Corvass SMS send failed: {response.StatusCode} - {error}");
        }
    }
    /*

    public Task<bool> SendOtpSmsAsync(string to, string otpCode, int expiryMinutes)
    {
        var message = $"Tek seferlik giriş kodunuz: {otpCode}. Kodun süresi {expiryMinutes} dakika sonra dolacak.";
        //var message = $"Your OTP code is {otpCode}. It will expire in {expiryMinutes} minutes.";
        return SendAsync(to, message).ContinueWith(t => t.IsCompletedSuccessfully);
    }
    public Task SendAsync(string to, string message, DateTime scheduledTime)
    {
        // Note: Corvass API may not support scheduling directly.
        // You might need to implement scheduling logic in your application.
        throw new NotImplementedException("Scheduled sending is not implemented.");
    }
    
     
     
     
         private readonly string _smsUrl;
    private readonly string _apiKey;
    private readonly string _apiSecret;

    public CorvassSmsSender(string smsUrl, string apiKey, string apiSecret)
    {
        _smsUrl = smsUrl;
        _apiKey = apiKey;
        _apiSecret = apiSecret;
    }


       public async Task SendAsync(SmsMessage message)
    {
        using var client = new HttpClient();

        var payload = new
        {
            Authentication = new
            {
                apikey = _apiKey,
                apisecret = _apiSecret
            },
            msisdnArray = new[] { message.To },
            message = message.Text,
            originator = "", // "AKAL YNT."
            senddate = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss"),
            tags = new[] { "customer", "crm" },
            description = "",
            messageType = "B", // B = Business, R = Regular
            recipientType = "" // "TACIR" (commercial) or "BIREYSEL" (individual)
        };

        var response = await client.PostAsJsonAsync(_smsUrl, payload);
        response.EnsureSuccessStatusCode();

        if (!response.IsSuccessStatusCode)
        {
            var error = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"Corvass SMS send failed: {response.StatusCode} - {error}");
        }
    }
  
     
{
    "Authentication": {
        "apikey": "{{apikey}}",
        "apisecret": "{{apisecret}}"
    }
    "message": "Mesaj metni",
    "msisdnArray": ["53xxxxxxxx", "05xxxxxxxxx", "905xxxxxxxxx"],

    "originator": "Corvass.NET",
    "senddate": "2021-10-01 00:00:00",
    "tags": ["kirtasiye", "indirim", "gönderim", "sms"],
    "description": "",
    “messageType”: “{B veya R}”,
    “recipientType”: “{TACIR veya BIREYSEL}”
}     
     
     
     
     
     */
}
