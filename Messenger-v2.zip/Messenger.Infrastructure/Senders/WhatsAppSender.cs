﻿using Messenger.Core.Options;
using Microsoft.Extensions.Options;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace Messenger.Infrastructure.Senders;

public class WhatsappSender : IWhatsAppMessageSender
{
    private readonly WhatsAppOptions _options;

    public WhatsappSender(IOptions<WhatsAppOptions> options)
    {
        _options = options.Value;
    }

    public async Task SendAsync(WhatsAppMessage message)
    {
        using var client = new HttpClient();
        client.DefaultRequestHeaders.Authorization =
            new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _options.ApiKey);//_accessToken

        var payload = new
        {
            messaging_product = "whatsapp",
            to = message.To,
            type = "text",
            text = new { body = message.Text }
        };

        var response = await client.PostAsJsonAsync(_options.ApiUrl, payload);
        response.EnsureSuccessStatusCode();
    }
}

/*
    private readonly string _wabaUrl;
    private readonly string _accessToken;

    public WhatsappSender(string wabaUrl, string accessToken)
    {
        _wabaUrl = wabaUrl;
        _accessToken = accessToken;
    }
*/
