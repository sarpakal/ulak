using System.Globalization;
using System.Text;
using System.Text.Json;
using AuthApi.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Messenger.Infrastructure.Senders;

/// <summary>
/// Sends OTP SMS via the Corvass API (Turkish mobile lines, +90).
/// Adapted from CorvassOtpClient provided by Turquoise Auto Inc.
/// </summary>
public class CorvassSmsSender : ISmsService
{
    private readonly HttpClient      _http;
    private readonly CorvassOptions  _options;
    private readonly ILogger<CorvassSmsSender> _logger;

    public CorvassSmsSender(
        HttpClient httpClient,
        IOptions<CorvassOptions> options,
        ILogger<CorvassSmsSender> logger)
    {
        _http    = httpClient;
        _options = options.Value;
        _logger  = logger;
    }

    public async Task<bool> SendOtpAsync(
        string phoneNumber,
        string otpCode,
        CancellationToken ct = default)
    {
        var payload = new
        {
            Authentication = new
            {
                apikey    = _options.ApiKey,
                apisecret = _options.ApiSecret,
            },
            message      = $"{otpCode} tek seferlik giriş kodunuzdur.",
            msisdnArray  = new[] { phoneNumber },
            originator   = _options.Originator,
            senddate     = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
            tags         = new[] { "otp", "authentication" },
            description  = "OTP",
            messageType  = _options.MessageType,
            recipientType= _options.RecipientType,
        };

        var json = JsonSerializer.Serialize(payload);

        using var request = new HttpRequestMessage(HttpMethod.Post, _options.SmsUrl)
        {
            // Corvass expects text/plain content type
            Content = new StringContent(json, Encoding.UTF8, "text/plain")
        };

        _logger.LogInformation("Corvass: sending OTP to {Phone}", phoneNumber);

        var response = await _http.SendAsync(request, ct);
        var body     = await response.Content.ReadAsStringAsync(ct);

        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning(
                "Corvass: non-success status {Status} for {Phone}. Body: {Body}",
                (int)response.StatusCode, phoneNumber, body);
            return false;
        }

        _logger.LogInformation("Corvass: OTP sent to {Phone}. Response: {Body}", phoneNumber, body);
        return true;
    }
}
