﻿using Messenger.Core.Options;
using Microsoft.Extensions.Options;

namespace Messenger.Infrastructure.Senders;

public class FcmPushSender : IPushNotificationSender
{
    private readonly FcmNotificationOptions _options;

    public FcmPushSender(IOptions<FcmNotificationOptions> options)
    {
        _options = options.Value;
    }


    public async Task SendAsync(PushMessage message)
    {
        using var client = new HttpClient();
        client.DefaultRequestHeaders.Authorization =
            new System.Net.Http.Headers.AuthenticationHeaderValue("key", "=" + _options.ServerKey);

        var payload = new
        {
            to = message.To, // Device token
            notification = new
            {
                title = message.Title,
                body = message.Body
            }
        };

        var response = await client.PostAsJsonAsync(_options.FcmEndpoint, payload);
        response.EnsureSuccessStatusCode();
    }
}
/*
    Token = "device-token",
    Notification = new Notification
    {
        Title = "Sarpwear Drop",
        Body = "New seasonal capsule is live!"
    }
*/

